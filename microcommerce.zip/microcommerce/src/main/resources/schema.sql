CREATE TABLE product
(
    id INT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    prix INT NOT NULL,
    prix_achat INT NOT NULL
);